<?php
/**
 * This is just a test file.
 */

function test() {
	echo 'Testing';
}